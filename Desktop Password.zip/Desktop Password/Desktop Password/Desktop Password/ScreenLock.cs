﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Desktop_Password
{
    public partial class ScreenLock : Form
    {
        public ScreenLock()
        {
            InitializeComponent();
        }

        public static void Locks()
        {

        }
    }
}
